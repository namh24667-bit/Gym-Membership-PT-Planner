# Cài đặt và sử dụng IronPulse v1.0.1

IronPulse chạy trên máy Windows cá nhân. Mỗi máy dùng một SQL Server và database cục bộ, có dữ liệu và tài khoản demo riêng. Các máy không tự đồng bộ. Website mặc định chỉ nghe loopback. Dữ liệu và doanh thu trên bản cài mới là số liệu mô phỏng cho đồ án.

## Chuẩn bị

| Thành phần | Cần cài |
|---|---|
| Windows | Windows x64. Kiểm tra **Settings → System → About → System type**. |
| Python | Python 3.12 x64 cho mọi người dùng. Bật Python Launcher hoặc xác định đường dẫn đến `python.exe`. [Python 3.12.10](https://www.python.org/downloads/release/python-31210/) |
| PowerShell | PowerShell 7 x64, bản MSI, đường dẫn mặc định `C:\Program Files\PowerShell\7\pwsh.exe`. [Cài PowerShell](https://learn.microsoft.com/en-us/powershell/scripting/install/installing-powershell-on-windows) |
| SQL Server | SQL Server Express 2022 hoặc 2025 cục bộ, dùng Windows Authentication. [Tải SQL Server Express và SSMS](https://www.microsoft.com/en-us/sql-server/sql-server-downloads) |
| ODBC | Microsoft ODBC Driver 18 x64. Cài Visual C++ Redistributable x64 nếu phiên bản driver yêu cầu. [ODBC và điều kiện cài](https://learn.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server) |

Mở **SQL Server Configuration Manager**. Trong **SQL Server Services**, tìm dịch vụ đang chạy, ví dụ **SQL Server (SQLEXPRESS)**. Trong **SQL Server Network Configuration**, kiểm **Shared Memory** của instance. Nếu tên dịch vụ là **SQL Server (MSSQLSERVER)** thì nhập `MSSQLSERVER` khi Setup hỏi. Trong PowerShell có thể kiểm nhanh:

```powershell
py -3.12 -c "import struct; print(struct.calcsize('P') * 8)"
Get-OdbcDriver -Name 'ODBC Driver 18 for SQL Server' -Platform '64-bit'
```

Tạo tài khoản Windows cục bộ tiêu chuẩn dành riêng cho Flask, ví dụ `IronPulseTeamApp`, qua **Settings → Accounts → Other users**. Tài khoản chạy Setup phải có quyền quản trị trên **SQL Server cục bộ** để tạo database, login và cấp quyền. Tài khoản Flask chỉ có quyền đọc cột và chạy thủ tục cần thiết của bản cài. Giữ mật khẩu Windows và mật khẩu ứng dụng trên máy của mình.

## Cài mới từ ZIP

1. Nhận `IronPulse_v1.0.1.zip` và mã SHA-256 từ Owner. Tính mã trong PowerShell rồi so trước khi giải nén.

   ```powershell
   Get-FileHash .\IronPulse_v1.0.1.zip -Algorithm SHA256
   ```

2. Giải nén vào thư mục cục bộ mới, ví dụ `C:\IronPulse-v1`. Dùng thư mục mà tài khoản runtime đọc được. Mở PowerShell tại đó và chạy `.\Setup-IronPulse.cmd`.
3. Nhập instance, tên database mới theo mẫu `IronPulse_Clean...QA` (mặc định `IronPulse_CleanDemoQA`), tài khoản Windows runtime và cổng loopback (mặc định `5443`). Nhập `CAI DAT` để tiếp tục. Nếu cần, dùng `-Python 'C:\Duong dan\python.exe'`. Dùng `-OfflineWheels` khi đã có thư mục wheel khớp `requirements-team.lock`. Setup thông thường cần truy cập kho phụ thuộc Python.
4. Khi thấy `CLEAN_DATASET_PASS` và `SETUP_DATABASE_PASS`, chạy các lệnh dưới đây. Windows có thể hỏi mật khẩu Windows của runtime tại lời nhắc `runas`. Lệnh `--credentials` dùng tài khoản Windows đã chạy Setup và hiển thị tám email cùng mật khẩu **ứng dụng** riêng.

   ```powershell
   .\Mo-IronPulse.cmd --version
   .\Mo-IronPulse.cmd --check
   .\Mo-IronPulse.cmd --credentials
   .\Mo-IronPulse.cmd
   ```

5. `CHECK_PASS` xác nhận kết nối SQL và đăng nhập. Khi thấy `READY`, mở [website ở cổng mặc định](http://localhost:5443/login) hoặc URL do launcher in ra. Dùng `.\Mo-IronPulse.cmd --restart` để khởi động lại và `.\Mo-IronPulse.cmd --stop` để dừng. Chạy `--check` khi bản cài đang dừng để cổng trống. Setup chạy lại trên bản đã cài chỉ xác minh database và quyền đã có.

## Cập nhật bản v1.0 có CleanDemo

1. Từ bản đang dùng, chạy `.\Mo-IronPulse.cmd --version` để xác nhận **1.0.0**, rồi `.\Mo-IronPulse.cmd --stop`.
2. Xác minh `Get-FileHash .\IronPulse_Update_v1.0.1.zip -Algorithm SHA256` theo mã Owner gửi. Giải nén ZIP cập nhật vào thư mục mới. Giữ nguyên nội dung giải nén để updater đối chiếu từng tệp với manifest.
3. Từ thư mục vừa giải nén, dưới tài khoản Windows quản trị SQL đã dùng lúc Setup, chạy lệnh sau và thay ba giá trị cho đúng máy.

   ```powershell
   .\Update-IronPulse.cmd -InstalledRoot 'C:\IronPulse-v1' -Package 'C:\Goi\IronPulse_Update_v1.0.1.zip' -SHA256 '<SHA-256 Owner cung cấp>'
   ```

4. Sau `UPDATE_PASS 1.0.1`, chạy `--version`, `--check` và mở lại từ **thư mục bản đã cập nhật**. Database, cấu hình và tài khoản demo hiện có tiếp tục được sử dụng. Updater xác minh đích CleanDemo, tạo backup COPY_ONLY có CHECKSUM trước khi đổi tệp và giữ biên nhận trong `instance/version-backups`. Updater đổi định nghĩa ba thủ tục và ghi dấu phiên bản SQL. Lược đồ bảng giữ nguyên.
5. Khi cần hoàn tác, dừng bản đang chạy. Từ bộ cập nhật đã giải nén, chạy `.\Update-IronPulse.cmd -InstalledRoot 'C:\IronPulse-v1' -Rollback`. Lệnh khôi phục tệp ứng dụng, manifest và định nghĩa SQL cũ theo checkpoint. Database giữ các giao dịch đã có và giao dịch tạo sau cập nhật. Sau đó xác minh lại `--version` và `--check`.

Muốn có đầy đủ dataset trên 10.000 dòng, cài từ ZIP vào **thư mục, database, tài khoản Windows và cổng riêng**. Bản cập nhật giữ số lượng từ bản đang dùng. Hai ZIP v1.0.1 dùng cùng payload. Đường nâng cấp trực tiếp từ 0.9.1-test và bản v1.0 còn dùng dataset legacy nằm ngoài phạm vi hỗ trợ của gói cập nhật. Setup khởi tạo database trống, còn Update dùng manifest để thay phiên bản trên bản cài được hỗ trợ.

## Kiểm đếm để bảo vệ đồ án

Trong SSMS, kết nối instance của máy bằng Windows Authentication. Chọn đúng database CleanDemo vừa cài trong danh sách trên thanh công cụ, mở [clean_count.sql](../ops/portable/clean_count.sql), rồi chọn **Execute**. Script chỉ đọc và kiểm tên database cùng marker CleanDemo. Kết quả gồm từng bảng, tổng đúng 18 bảng nghiệp vụ và trạng thái mốc **hơn 10.000** ở dòng cuối.

## Bốn vai trò

| Vai trò | Nội dung trình diễn |
|---|---|
| Hội viên | Hồ sơ, danh mục gói, hợp đồng, PT và lớp theo quyền. Hủy lớp đủ 5 giờ trước giờ tập để hoàn lượt. |
| Nhân viên | Tra cứu hội viên, HLV và lớp, tư vấn gói, thu tiền, kích hoạt và mở biên lai. |
| Huấn luyện viên | Lịch được phân công, chi tiết PT, thông tin liên hệ khi đủ điều kiện và danh sách lớp phụ trách. |
| Quản lý | Dashboard, báo cáo, nhân sự, phòng tập, thiết bị, bảo trì, gói và lớp. |

Bản cài mới có các tài khoản `member-pt`, `member-class`, `member-expired`, `member-quota`, `staff`, `trainer-pt`, `trainer-class` và `manager`. Dùng `--credentials` để xem email và mật khẩu trên máy mình. Lịch được tạo tương đối theo ngày cài. Khi các ca mẫu đã qua, tạo lịch mới qua màn hình nghiệp vụ để trình diễn.

## Khi có lỗi

- **Không kết nối SQL hoặc HTTP 503**. Kiểm tên instance, dịch vụ, Shared Memory, ODBC x64 và tài khoản runtime. Khi worker đã dừng, chạy `--check` để lấy bước lỗi. Ghi phiên bản, màn hình, HTTP hoặc SQLSTATE và bước tái hiện, che thông tin riêng trong ảnh.
- **Database đã tồn tại**. Dùng đúng thư mục của bản cài cũ. Khi cần cài riêng, chọn database và tài khoản runtime mới. Setup không ghi đè dữ liệu.
- **Cổng đã được dùng**. Chọn cổng loopback khác cho bản cài mới hoặc dừng đúng website đang dùng cổng.
- **Lỗi hash hoặc lỗi cập nhật**. Giữ ZIP và checkpoint, đối chiếu mã với Owner. Dừng worker trước khi cập nhật hoặc hoàn tác. Nếu còn khóa `instance/portable-update.lock` sau khi đã xác minh tiến trình cập nhật kết thúc, nhờ người quản lý bản cài kiểm tra checkpoint trước khi bỏ riêng dấu khóa và chạy rollback.
- **Không đọc được credentials**. Dùng đúng tài khoản Windows đã chạy Setup. Mật khẩu Windows dùng ở `runas`. Mật khẩu ứng dụng dùng ở trang đăng nhập. Giữ cả hai ngoài báo cáo lỗi và kênh chia sẻ.
